package main

import (
	"context"
	"encoding/json"
	"errors"
	"io/ioutil"
	"net/http"
	"strings"
	"time"

	jwt "github.com/dgrijalva/jwt-go"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/gorm"
)

type Claims struct {
	Admin  bool `json:"admin"`
	UserID uint `json:"user_id"`
	jwt.StandardClaims
}

func isAdmin(r *http.Request) bool {
	return r.Context().Value("claims").(*Claims).Admin
}

func auth(w http.ResponseWriter, r *http.Request) {
	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte(err.Error()))
		return
	}

	var m map[string]string
	if err = json.Unmarshal(body, &m); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte(err.Error()))
		return
	}
	if m["nickname"] == "" {
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte("You must provide a nickname."))
		return
	}
	if m["password"] == "" {
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte("You must provide a password."))
		return
	}

	var user User
	if err := DB.Where(&User{Nickname: m["nickname"]}).First(&user).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			w.WriteHeader(http.StatusNotFound)
			w.Write([]byte("User doesn't exists."))
		} else {
			w.WriteHeader(http.StatusInternalServerError)
			w.Write([]byte(err.Error()))
		}

		return
	}

	if bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(m["password"])) != nil {
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte("Invalid password."))
		return
	}

	token, err := createToken(&user)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte("Cannot generate token: " + err.Error()))
		return
	}

	data := map[string]interface{}{
		"token":    token,
		"user_id":  user.ID,
		"is_admin": user.Admin,
	}
	json, err := json.Marshal(data)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte(err.Error()))
		return
	}

	w.Header().Set("Authorization", "Bearer "+token)
	w.WriteHeader(http.StatusOK)
	w.Write(json)
}

func createToken(u *User) (string, error) {
	claims := Claims{
		Admin:          u.Admin,
		UserID:         u.ID,
		StandardClaims: jwt.StandardClaims{ExpiresAt: time.Now().Add(time.Hour).Unix()},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString([]byte(JWT_SECRET))
}

func parseToken(tokenString string) (*Claims, error) {
	token, err := jwt.ParseWithClaims(tokenString, &Claims{},
		func(t *jwt.Token) (interface{}, error) {
			return []byte(JWT_SECRET), nil
		})
	if err != nil {
		return nil, err
	}

	return token.Claims.(*Claims), err
}

func middlewareToken(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		token := r.Header.Get("Authorization")
		if token == "" {
			w.WriteHeader(http.StatusUnauthorized)
			w.Write([]byte("Missing Authorization Header."))
			return
		}

		token = strings.Replace(token, "Bearer ", "", 1)
		claims, err := parseToken(token)
		if err != nil {
			w.WriteHeader(http.StatusUnauthorized)
			w.Write([]byte("Invalid Token."))
			return
		}

		context := context.WithValue(r.Context(), "claims", claims)
		next.ServeHTTP(w, r.WithContext(context))
	})
}
