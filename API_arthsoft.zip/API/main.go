package main

import (
	"errors"
	"log"
	"net/http"
	"time"

	"github.com/gorilla/mux"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

const JWT_SECRET = "хороший скан :)"
const ADMIN_NICKNAME = "admin"
const ADMIN_PASSWORD = "admin"

var DB *gorm.DB

func createAdmin() {
	if (!errors.Is(DB.First(&User{Nickname: ADMIN_NICKNAME}).Error, gorm.ErrRecordNotFound)) {
		return
	}

	password, err := bcrypt.GenerateFromPassword([]byte(ADMIN_PASSWORD), bcrypt.DefaultCost)
	if err != nil {
		log.Panicln("Cannot hash admin password.")
	}

	admin := User{
		Admin:    true,
		Nickname: ADMIN_NICKNAME,
		Password: string(password),
	}

	if err := DB.Create(&admin).Error; err != nil {
		log.Panicln("Cannot create admin: " + err.Error())
	}
}

func main() {
	var err error
	DB, err = gorm.Open(sqlite.Open("api.sqlite"), &gorm.Config{})
	if err != nil {
		log.Panicln(err)
	}

	DB.AutoMigrate(&Submission{}, &User{})
	DB = DB.Debug()

	createAdmin()

	router := mux.NewRouter()
	router.HandleFunc("/auth", auth).Methods(http.MethodPost)

	submissionRouter := router.PathPrefix("/submissions").Subrouter()
	submissionRouter.Handle("/", middlewareToken(http.HandlerFunc(createSubmission))).Methods(http.MethodPost)
	submissionRouter.Handle("/", middlewareToken(http.HandlerFunc(readSubmissions))).Methods(http.MethodGet)
	submissionRouter.Handle("/{id:[0-9]+}", middlewareToken(http.HandlerFunc(readSubmission))).Methods(http.MethodGet)
	submissionRouter.Handle("/{id:[0-9]+}", middlewareToken(http.HandlerFunc(updateSubmission))).Methods(http.MethodPut)
	submissionRouter.Handle("/{id:[0-9]+}", middlewareToken(http.HandlerFunc(deleteSubmission))).Methods(http.MethodDelete)

	userRouter := router.PathPrefix("/users").Subrouter()
	userRouter.HandleFunc("/", createUser).Methods(http.MethodPost)
	userRouter.Handle("/", middlewareToken(http.HandlerFunc(readUsers))).Methods(http.MethodGet)
	userRouter.Handle("/{id:[0-9]+}", middlewareToken(http.HandlerFunc(readUser))).Methods(http.MethodGet)
	userRouter.Handle("/{id:[0-9]+}", middlewareToken(http.HandlerFunc(updateUser))).Methods(http.MethodPut)
	userRouter.Handle("/{id:[0-9]+}", middlewareToken(http.HandlerFunc(deleteUser))).Methods(http.MethodDelete)

	server := &http.Server{
		Addr:         ":8080",
		WriteTimeout: time.Second * 15,
		ReadTimeout:  time.Second * 15,
		IdleTimeout:  time.Second * 60,
		Handler:      router,
	}
	log.Fatalln(server.ListenAndServe())
}
