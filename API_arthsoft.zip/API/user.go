package main

import (
	"encoding/json"
	"errors"
	"io/ioutil"
	"net/http"
	"strconv"

	"github.com/gorilla/mux"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/gorm"
)

type User struct {
	gorm.Model
	Admin    bool   `json:"-"`
	Nickname string `json:"nickname"`
	Password string `json:"password"`

	Submissions []Submission `gorm:"constraint:OnDelete:CASCADE"`
}

func (u *User) Validate() error {
	if u.Nickname == "" {
		return errors.New("Nickname must not be empty.")
	}

	if u.Password == "" {
		return errors.New("Password must not be empty.")
	}

	return nil
}

func UserPermitted(r *http.Request, id uint) bool {
	return r.Context().Value("claims").(*Claims).UserID == id
}

func createUser(w http.ResponseWriter, r *http.Request) {
	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte(err.Error()))
		return
	}

	var user User
	if err = json.Unmarshal(body, &user); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte(err.Error()))
		return
	}

	if err = user.Validate(); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte(err.Error()))
		return
	}

	err = DB.Where(&User{Nickname: user.Nickname}).First(&User{}).Error
	if err == nil {
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte("User already exists."))
		return
	} else if !errors.Is(err, gorm.ErrRecordNotFound) {
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte(err.Error()))
		return
	}

	hash, err := bcrypt.GenerateFromPassword([]byte(user.Password), bcrypt.DefaultCost)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte(err.Error()))
		return
	}
	user.Password = string(hash)

	if err = DB.Create(&user).Error; err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte(err.Error()))
		return
	}

	w.WriteHeader(http.StatusNoContent)
	w.Write(nil)
}

func readUsers(w http.ResponseWriter, r *http.Request) {
	if !isAdmin(r) {
		w.WriteHeader(http.StatusUnauthorized)
		w.Write(nil)
		return
	}

	var users []User
	if err := DB.Find(&users).Error; err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte(err.Error()))
		return
	}

	json, err := json.Marshal(users)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte(err.Error()))
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(json)
}

func readUser(w http.ResponseWriter, r *http.Request) {
	id, _ := strconv.Atoi(mux.Vars(r)["id"])

	if !(isAdmin(r) || UserPermitted(r, uint(id))) {
		w.WriteHeader(http.StatusUnauthorized)
		w.Write(nil)
		return
	}

	var user User
	if err := DB.Preload("Submissions").First(&user, id).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			w.WriteHeader(http.StatusNotFound)
		} else {
			w.WriteHeader(http.StatusInternalServerError)
		}

		w.Write([]byte(err.Error()))
		return
	}

	json, err := json.Marshal(user)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte(err.Error()))
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(json)
}

func updateUser(w http.ResponseWriter, r *http.Request) {
	id, _ := strconv.Atoi(mux.Vars(r)["id"])

	if !(isAdmin(r) || UserPermitted(r, uint(id))) {
		w.WriteHeader(http.StatusUnauthorized)
		w.Write(nil)
		return
	}

	var user User
	if err := DB.First(&user, id).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			w.WriteHeader(http.StatusNotFound)
		} else {
			w.WriteHeader(http.StatusInternalServerError)
		}

		w.Write([]byte(err.Error()))
		return
	}
	oldNickname := user.Nickname
	oldPassword := user.Password

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte(err.Error()))
		return
	}

	if err = json.Unmarshal(body, &user); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte(err.Error()))
		return
	}

	if err = user.Validate(); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte(err.Error()))
		return
	}

	if user.Nickname != oldNickname {
		err := DB.Where(&User{Nickname: user.Nickname}).First(&User{}).Error
		if err == nil {
			w.WriteHeader(http.StatusBadRequest)
			w.Write([]byte("Nickname is already taken."))
			return
		} else if !errors.Is(err, gorm.ErrRecordNotFound) {
			w.WriteHeader(http.StatusInternalServerError)
			w.Write([]byte(err.Error()))
			return
		}
	}

	if user.Password != oldPassword {
		hash, err := bcrypt.GenerateFromPassword([]byte(user.Password), bcrypt.DefaultCost)
		if err != nil {
			w.WriteHeader(http.StatusInternalServerError)
			w.Write([]byte(err.Error()))
			return
		}
		user.Password = string(hash)
	}

	// Prevent id manipulation
	user.ID = uint(id)

	if err = DB.Save(&user).Error; err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte(err.Error()))
		return
	}

	w.WriteHeader(http.StatusNoContent)
	w.Write(nil)
}

func deleteUser(w http.ResponseWriter, r *http.Request) {
	id, _ := strconv.Atoi(mux.Vars(r)["id"])

	if !(isAdmin(r) || UserPermitted(r, uint(id))) {
		w.WriteHeader(http.StatusUnauthorized)
		w.Write(nil)
		return
	}

	if err := DB.Delete(&User{}, id).Error; err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte(err.Error()))
		return
	}

	w.WriteHeader(http.StatusNoContent)
	w.Write(nil)
}
