package main

//TODO: validate

import (
	"encoding/json"
	"errors"
	"io/ioutil"
	"net/http"
	"strconv"

	"github.com/gorilla/mux"
	"gorm.io/gorm"
)

type Submission struct {
	gorm.Model
	Resume          string `json:"resume"`
	Picture         string `json:"picture"`
	FirstName       string `json:"first_name"`
	LastName        string `json:"last_name"`
	Mail            string `json:"mail"`
	PhoneNumber     string `json:"phone_number"`
	Address         string `json:"address"`          // coord (Google Maps)
	WorkExperiences string `json:"work_experiences"` // sep=;
	Degrees         string `json:"degrees"`          // sep=;
	Comment         string `json:"comment"`          // sep=;

	UserID uint
}

func (s *Submission) Validate() error {
	if len(s.Resume) == 0 {
		return errors.New("Resume must be provided.")
	}

	if s.FirstName == "" {
		return errors.New("First name must not be empty.")
	}

	if s.LastName == "" {
		return errors.New("Last name must not be empty.")
	}

	if s.Mail == "" {
		return errors.New("Mail must not be empty.")
	}

	return nil
}

func UserHasThisSubmission(r *http.Request, submissionID uint) bool {
	userID := r.Context().Value("claims").(*Claims).UserID

	var submission Submission
	DB.Where("id = ?", submissionID).First(&submission)

	return submission.UserID == userID
}

func createSubmission(w http.ResponseWriter, r *http.Request) {
	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte(err.Error()))
		return
	}

	var submission Submission
	if err = json.Unmarshal(body, &submission); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte(err.Error()))
		return
	}

	if err = submission.Validate(); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte(err.Error()))
		return
	}

	submission.UserID = r.Context().Value("claims").(*Claims).UserID
	if err = DB.Create(&submission).Error; err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte(err.Error()))
		return
	}

	w.WriteHeader(http.StatusNoContent)
	w.Write(nil)
}

func readSubmissions(w http.ResponseWriter, r *http.Request) {
	var submissions []map[string]interface{}
	var err error

	if isAdmin(r) {
		err = DB.Model(&Submission{}).Find(&submissions).Error
	} else {
		err = DB.Model(&Submission{}).Find(&submissions).Error
	}
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte(err.Error()))
		return
	}

	// Preserve bandwidth
	for _, v := range submissions {
		delete(v, "picture")
		delete(v, "resume")
	}

	json, err := json.Marshal(submissions)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte(err.Error()))
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(json)
}

func readSubmission(w http.ResponseWriter, r *http.Request) {
	id, _ := strconv.Atoi(mux.Vars(r)["id"])

	if !(isAdmin(r) || UserHasThisSubmission(r, uint(id))) {
		w.WriteHeader(http.StatusUnauthorized)
		w.Write(nil)
		return
	}

	var submission Submission
	if err := DB.First(&submission, id).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			w.WriteHeader(http.StatusNotFound)
		} else {
			w.WriteHeader(http.StatusInternalServerError)
		}

		w.Write([]byte(err.Error()))
		return
	}

	json, err := json.Marshal(submission)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte(err.Error()))
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(json)
}

func updateSubmission(w http.ResponseWriter, r *http.Request) {
	id, _ := strconv.Atoi(mux.Vars(r)["id"])

	if !(isAdmin(r) || UserHasThisSubmission(r, uint(id))) {
		w.WriteHeader(http.StatusUnauthorized)
		w.Write(nil)
		return
	}

	var submission Submission
	if err := DB.First(&submission, id).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			w.WriteHeader(http.StatusNotFound)
		} else {
			w.WriteHeader(http.StatusInternalServerError)
		}

		w.Write([]byte(err.Error()))
		return
	}

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte(err.Error()))
		return
	}

	if err = json.Unmarshal(body, &submission); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte(err.Error()))
		return
	}

	if err = submission.Validate(); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte(err.Error()))
		return
	}

	// Prevent id manipulation
	submission.ID = uint(id)

	if err = DB.Save(&submission).Error; err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte(err.Error()))
		return
	}

	w.WriteHeader(http.StatusNoContent)
	w.Write(nil)
}

func deleteSubmission(w http.ResponseWriter, r *http.Request) {
	id, _ := strconv.Atoi(mux.Vars(r)["id"])

	if !(isAdmin(r) || UserHasThisSubmission(r, uint(id))) {
		w.WriteHeader(http.StatusUnauthorized)
		w.Write(nil)
		return
	}

	if err := DB.Delete(&Submission{}, id).Error; err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte(err.Error()))
		return
	}

	w.WriteHeader(http.StatusNoContent)
	w.Write(nil)
}
