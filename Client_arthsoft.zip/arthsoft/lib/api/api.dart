import "dart:convert";

import "package:flutter/widgets.dart";
import "package:http/http.dart" as http;

import "../models/user.dart";
import "../models/submission.dart";
import "global.dart";

final apiConsumer = _ApiConsumer();

class _ApiConsumer {
  final userApi = _UserApi();
  final submissionApi = _SubmissionApi();

  String _token;
  int _userId;
  bool _isAdmin = false;
  bool _isLogged = false;

  bool get isAdmin => _isAdmin;
  bool get isLogged => _isLogged;

  void logout() {
    _token = "";
    _userId = null;
    _isAdmin = false;
    _isLogged = false;
    headers.remove("Authorization");
  }

  Future<bool> auth(UserModel user, BuildContext context) async {
    try {
      var response = await http.post(ApiUrl + "/auth", body: user.toJson());

      if (response.statusCode == 200) {
        var data = json.decode(response.body);
        _token = data["token"];
        _userId = data["user_id"];
        _isAdmin = data["is_admin"];
        _isLogged = true;
        headers["Authorization"] = "Bearer " + _token;

        return true;
      }

      showSnackBar(context, response.body, false);
    } catch (e) {
      showSnackBar(context, e.toString(), false);
    }

    return false;
  }
}

class _UserApi {
  Future<bool> create(UserModel user, BuildContext context) async {
    try {
      var response = await http.post(ApiUserUrl + "/", body: user.toJson());

      if (response.statusCode == 204) {
        showSnackBar(context, "User successfully created.", true);
        return true;
      }

      showSnackBar(context, response.body, false);
    } catch (e) {
      showSnackBar(context, e.toString(), false);
    }

    return false;
  }

  Future<List<UserModel>> reads(BuildContext context) async {
    try {
      var response = await http.get(ApiUserUrl + "/", headers: headers);

      if (response.statusCode == 200) {
        return (json.decode(response.body) as List)
            .map((u) => UserModel.fromJson(u))
            .toList();
      }

      showSnackBar(
          context,
          (response.statusCode == 401) ? "Unauthorized." : response.body,
          false);
    } catch (e) {
      showSnackBar(context, e.toString(), false);
    }

    return null;
  }

  Future<bool> update(UserModel user, BuildContext context, {int id}) async {
    try {
      var response = await http.put(
          ApiUserUrl + "/${id ?? apiConsumer._userId}",
          body: user.toJson(),
          headers: headers);

      if (response.statusCode == 204) {
        showSnackBar(context, "Updated successfully", true);
        return true;
      }

      showSnackBar(context,
          response.statusCode == 401 ? "Unauthorized." : response.body, false);
    } catch (e) {
      showSnackBar(context, e.toString(), false);
    }

    return false;
  }

  Future<bool> delete(BuildContext context, {int id}) async {
    try {
      var response = await http.delete(
          ApiUserUrl + "/${id ?? apiConsumer._userId}",
          headers: headers);

      if (response.statusCode == 204) {
        // Deleted self
        if (id == null) {
          apiConsumer.logout();
        }
        showSnackBar(context, "Deleted successfully", true);
        return true;
      }

      showSnackBar(context,
          response.statusCode == 401 ? "Unauthorized." : response.body, false);
    } catch (e) {
      showSnackBar(context, e.toString(), false);
    }

    return false;
  }
}

class _SubmissionApi {
  Future<bool> create(SubmissionModel submission, BuildContext context) async {
    try {
      var response = await http.post(ApiSubmissionUrl + "/",
          body: submission.toJson(), headers: headers);

      if (response.statusCode == 204) {
        showSnackBar(context, "Resume successfully sent.", true);
        return true;
      }

      showSnackBar(context, response.body, false);
    } catch (e) {
      showSnackBar(context, e.toString(), false);
    }

    return false;
  }

  Future<List<SubmissionModel>> reads(BuildContext context) async {
    try {
      var response = await http.get(ApiSubmissionUrl + "/", headers: headers);

      if (response.statusCode == 200) {
        return (json.decode(response.body) as List)
            .map((s) => SubmissionModel.fromJson(s))
            .toList();
      }

      showSnackBar(
          context,
          (response.statusCode == 401) ? "Unauthorized." : response.body,
          false);
    } catch (e) {
      showSnackBar(context, e.toString(), false);
    }

    return null;
  }

  Future<SubmissionModel> read(BuildContext context, int id) async {
    try {
      var response =
          await http.get(ApiSubmissionUrl + "/$id", headers: headers);

      if (response.statusCode == 200) {
        return SubmissionModel.fromJson(json.decode(response.body));
      }

      showSnackBar(
          context,
          (response.statusCode == 401) ? "Unauthorized." : response.body,
          false);
    } catch (e) {
      showSnackBar(context, e.toString(), false);
    }

    return null;
  }

  Future<bool> delete(BuildContext context, int id) async {
    try {
      var response =
          await http.delete(ApiSubmissionUrl + "/$id", headers: headers);

      if (response.statusCode == 204) {
        showSnackBar(context, "Deleted successfully.", true);
        return true;
      }

      showSnackBar(context,
          response.statusCode == 401 ? "Unauthorized." : response.body, false);
    } catch (e) {
      showSnackBar(context, e.toString(), false);
    }

    return false;
  }
}
