import "package:flutter/material.dart";
import "package:flutter/widgets.dart";

const ApiUrl = "http://192.168.1.23:8080";
const ApiUserUrl = ApiUrl + "/users";
const ApiSubmissionUrl = ApiUrl + "/submissions";

final Map<String, String> headers = {};

void showSnackBar(BuildContext context, String text, bool success) {
  Scaffold.of(context).showSnackBar(SnackBar(
    content: Text(text),
    backgroundColor: success ? Colors.green : Colors.red,
  ));
}
