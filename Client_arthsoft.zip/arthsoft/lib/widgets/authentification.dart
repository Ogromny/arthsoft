import "package:flutter/material.dart";
import "package:flutter/widgets.dart";

import "../api/api.dart";
import "../models/user.dart";

class AuthentificationWidget extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _AuthentificationWidgetState();
}

class _AuthentificationWidgetState extends State<AuthentificationWidget> {
  bool _isLoading = false;
  String _nickname;
  String _password;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(20.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "Authentification",
            style: TextStyle(fontSize: 20),
          ),
          SizedBox(height: 40.0),
          TextField(
            keyboardType: TextInputType.text,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              labelText: "Nickname",
            ),
            onChanged: (value) => {_nickname = value},
          ),
          SizedBox(height: 20.0),
          TextField(
            keyboardType: TextInputType.visiblePassword,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              labelText: "Password",
            ),
            onChanged: (value) => {_password = value},
          ),
          SizedBox(height: 20.0),
          Builder(
            builder: (BuildContext context) {
              return RaisedButton(
                child: _isLoading
                    ? LinearProgressIndicator(value: null)
                    : Text("Login"),
                onPressed: () {
                  _signIn(context);
                },
              );
            },
          ),
        ],
      ),
    );
  }

  void _signIn(BuildContext context) async {
    setState(() => {_isLoading = true});

    var user = UserModel(nickname: _nickname, password: _password);
    if (await apiConsumer.auth(user, context)) {
      Navigator.pushNamedAndRemoveUntil(context, "/", (_) => false);
    }

    setState(() => {_isLoading = false});
  }
}
