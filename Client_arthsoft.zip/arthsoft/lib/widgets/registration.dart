import "package:flutter/material.dart";

import "../api/api.dart";
import "../models/user.dart";

class RegistrationWidget extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _RegistrationWidgetState();
}

class _RegistrationWidgetState extends State<RegistrationWidget> {
  bool _isLoading = false;
  String _nickname;
  String _password;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(20.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "Registration",
            style: TextStyle(fontSize: 20),
          ),
          SizedBox(height: 40.0),
          TextField(
            keyboardType: TextInputType.text,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              labelText: "Nickname",
            ),
            onChanged: (value) => {_nickname = value},
          ),
          SizedBox(height: 20.0),
          TextField(
            keyboardType: TextInputType.visiblePassword,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              labelText: "Password",
            ),
            onChanged: (value) => {_password = value},
          ),
          SizedBox(height: 20.0),
          Builder(builder: (BuildContext context) {
            return RaisedButton(
              child: _isLoading
                  ? LinearProgressIndicator(value: null)
                  : Text("Register"),
              onPressed: () {
                _signUp(context);
              },
            );
          })
        ],
      ),
    );
  }

  void _signUp(BuildContext context) async {
    setState(() => {_isLoading = true});

    var user = UserModel(nickname: _nickname, password: _password);

    await apiConsumer.userApi.create(user, context);

    setState(() => {_isLoading = false});
  }
}
