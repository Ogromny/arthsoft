import "package:flutter/material.dart";
import "package:flutter/widgets.dart";

import "../api/api.dart";
import "../models/user.dart";

class MeWidget extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _MeWidgetState();
}

class _MeWidgetState extends State<MeWidget> {
  bool _isLoading = false;
  String _nickname = "";
  String _password = "";

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(20.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(height: 40.0),
          TextField(
            keyboardType: TextInputType.text,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              labelText: "Nickname",
            ),
            onChanged: (value) => {_nickname = value},
          ),
          SizedBox(height: 20.0),
          TextField(
            keyboardType: TextInputType.text,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              labelText: "Password",
            ),
            onChanged: (value) => {_password = value},
          ),
          SizedBox(height: 20.0),
          Builder(
            builder: (BuildContext context) {
              return ButtonBar(
                children: [
                  RaisedButton(
                    child: _isLoading
                        ? LinearProgressIndicator(value: null)
                        : Text("Update"),
                    color: Colors.green,
                    onPressed: () {
                      _updateUser(context);
                    },
                  ),
                  RaisedButton(
                    child: _isLoading
                        ? LinearProgressIndicator(value: null)
                        : Text("Delete"),
                    color: Colors.red,
                    onPressed: () {
                      _deleteUser(context);
                    },
                  )
                ],
              );
            },
          )
        ],
      ),
    );
  }

  void _updateUser(BuildContext context) async {
    setState(() => {_isLoading = true});

    var user = UserModel(nickname: _nickname, password: _password);
    await apiConsumer.userApi.update(user, context);

    setState(() => {_isLoading = false});
  }

  void _deleteUser(BuildContext context) async {
    setState(() => {_isLoading = true});

    if (await apiConsumer.userApi.delete(context)) {
      Navigator.pushNamedAndRemoveUntil(context, "/login", (_) => false);
    }

    setState(() => {_isLoading = false});
  }
}
