import "dart:convert";

import "package:flutter/material.dart";
import "package:flutter/scheduler.dart";
import "package:flutter/widgets.dart";
import "package:google_maps_flutter/google_maps_flutter.dart";
import "package:native_pdf_view/native_pdf_view.dart";

import "../api/api.dart";
import "../models/submission.dart";

class MyResumes extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _MyResumesState();
}

class _MyResumesState extends State<MyResumes> {
  List<SubmissionModel> _submissions = [];

  void initState() {
    super.initState();
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      _submissions = await apiConsumer.submissionApi.reads(context);
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return _submissions.length != 0
        ? RefreshIndicator(
            child: ListView.builder(
              itemCount: (_submissions.length * 2) - 1,
              itemBuilder: (BuildContext context, int i) {
                if (i.isOdd) {
                  return Divider(height: 1.0);
                }

                final index = i ~/ 2;
                return ListTile(
                  title: Text(
                    _submissions[index].firstName +
                        " " +
                        _submissions[index].lastName,
                    style: TextStyle(fontSize: 18.0),
                  ),
                  onTap: () {
                    _showResume(context, _submissions[index].id);
                  },
                  trailing: StatefulBuilder(
                    // Builder // TODO ?
                    builder: (BuildContext context, StateSetter setState) =>
                        PopupMenuButton<int>(
                      onSelected: (int submissionId) async {
                        if (await _deleteSubmission(context, submissionId)) {
                          setState(() {});
                        }
                      },
                      itemBuilder: (BuildContext context) => [
                        PopupMenuItem(
                            child: Text("Delete"),
                            value: _submissions[index].id),
                      ],
                    ),
                  ),
                );
              },
            ),
            onRefresh: () async {
              _submissions = await apiConsumer.submissionApi.reads(context);
              setState(() {});
            },
          )
        : Center(
            child: CircularProgressIndicator(),
          );
  }

  Future<bool> _deleteSubmission(BuildContext context, int submissionId) async {
    return await apiConsumer.submissionApi.delete(context, submissionId);
  }

  Future<void> _showResume(BuildContext context, int submissionId) async {
    var submission =
        await apiConsumer.submissionApi.read(context, submissionId);

    LatLng coord;
    if (submission.address?.isNotEmpty ?? false) {
      var coords = submission.address.split(",");
      coord = LatLng(double.parse(coords[0]), double.parse(coords[1]));
    }

    if (submission == null) {
      return;
    }

    showDialog(
      context: context,
      builder: (_) => Dialog(
        child: Container(
          padding: EdgeInsets.all(8.0),
          child: SingleChildScrollView(
            child: Column(
              children: [
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  (submission.picture?.isNotEmpty ?? false)
                      ? Image.memory(base64Decode(submission.picture),
                          height: 200.0, width: 200.0)
                      : SizedBox(
                          height: 200.0,
                          child: Text("No picture"),
                        ),
                ]),
                SizedBox(height: 16.0),
                TextField(
                  controller: TextEditingController.fromValue(
                    TextEditingValue(text: submission.firstName),
                  ),
                  enabled: false,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: "First Name",
                    isDense: true,
                  ),
                ),
                SizedBox(height: 16.0),
                TextField(
                  controller: TextEditingController.fromValue(
                    TextEditingValue(text: submission.lastName),
                  ),
                  enabled: false,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: "Last Name",
                    isDense: true,
                  ),
                ),
                SizedBox(height: 16.0),
                TextField(
                  controller: TextEditingController.fromValue(
                      TextEditingValue(text: submission.mail)),
                  enabled: false,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: "Email address",
                    isDense: true,
                  ),
                ),
                SizedBox(height: 16.0),
                TextField(
                  controller: TextEditingController.fromValue(
                    TextEditingValue(text: submission.phoneNumber),
                  ),
                  enabled: false,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: "Phone number",
                    isDense: true,
                  ),
                ),
                SizedBox(height: 16.0),
                SizedBox(
                  height: 256.0,
                  child: coord == null
                      ? Text("No address")
                      : GoogleMap(
                          initialCameraPosition: CameraPosition(target: coord),
                          markers: Set()
                            ..add(
                              Marker(
                                position: coord,
                                markerId: MarkerId(submission.firstName +
                                    " " +
                                    submission.lastName),
                              ),
                            ),
                        ),
                ),
                SizedBox(height: 16.0),
                TextField(
                  controller: TextEditingController.fromValue(
                    TextEditingValue(text: submission.workExperiences),
                  ),
                  enabled: false,
                  keyboardType: TextInputType.multiline,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: "Work experiences",
                    isDense: true,
                  ),
                  minLines: 2,
                  maxLines: null,
                ),
                SizedBox(height: 16.0),
                TextField(
                  controller: TextEditingController.fromValue(
                    TextEditingValue(text: submission.degrees),
                  ),
                  enabled: false,
                  keyboardType: TextInputType.multiline,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: "Degrees",
                    isDense: true,
                  ),
                  minLines: 2,
                  maxLines: null,
                ),
                SizedBox(height: 16.0),
                TextField(
                  controller: TextEditingController.fromValue(
                    TextEditingValue(text: submission.comment),
                  ),
                  enabled: false,
                  keyboardType: TextInputType.multiline,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: "Any comments ?",
                    isDense: true,
                  ),
                  minLines: 2,
                  maxLines: null,
                ),
                SizedBox(height: 24.0),
                Row(
                  children: [
                    RaisedButton(
                      color: Colors.green,
                      child: Text(
                        "Open resume",
                        style: TextStyle(color: Colors.white),
                      ),
                      onPressed: () async {
                        showDialog(
                            context: context,
                            builder: (_) => PdfView(
                                controller: PdfController(
                                    document: PdfDocument.openData(
                                        base64Decode(submission.resume)))));
                      },
                    )
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
