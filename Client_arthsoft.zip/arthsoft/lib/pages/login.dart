import "package:flutter/material.dart";

import "../widgets/authentification.dart";
import "../widgets/registration.dart";

class LoginPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  int _currentIndex = 0;
  final List<Widget> _children = [
    AuthentificationWidget(),
    RegistrationWidget(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Arthsoft CV"),
        automaticallyImplyLeading: false,
      ),
      bottomNavigationBar: BottomNavigationBar(
        onTap: (int index) => setState(() => {_currentIndex = index}),
        currentIndex: _currentIndex,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.lock_open),
            title: Text("Login"),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.create),
            title: Text("Sign up"),
          ),
        ],
      ),
      body: _children[_currentIndex],
    );
  }
}
