import "dart:convert";
import "dart:io";

import "package:file_picker/file_picker.dart";
import "package:flutter/material.dart";
import "package:flutter/widgets.dart";
import "package:google_map_location_picker/google_map_location_picker.dart";
import "package:google_maps_flutter/google_maps_flutter.dart";
import "package:image_picker/image_picker.dart";

import "../api/api.dart";
import "../models/submission.dart";
import "../widgets/me.dart";
import "../widgets/my_resumes.dart";

class HomePage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _currentIndex = 0;
  final List<Widget> _children = [
    MeWidget(),
    //if (apiConsumer.isAdmin) UsersWidget(),
    MyResumes(),
  ];
  // used for _resumeDialog
  File _picture;
  final _picturePicker = ImagePicker();
  File _resume;
  String _firstName;
  String _lastName;
  String _mail;
  String _phoneNumber;
  String _address;
  String _wordExperiences;
  String _degrees;
  String _comment;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text("Arthsoft CV"),
          automaticallyImplyLeading: false,
          actions: [
            IconButton(
              icon: Icon(Icons.exit_to_app),
              tooltip: "Logout",
              onPressed: () {
                apiConsumer.logout();
                Navigator.pushNamedAndRemoveUntil(
                    context, "/login", (_) => false);
              },
            ),
          ]),
      bottomNavigationBar: BottomNavigationBar(
        onTap: (int index) => setState(() => {_currentIndex = index}),
        currentIndex: _currentIndex,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.face),
            title: Text("Me"),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.art_track),
            title: Text(apiConsumer.isAdmin ? "Resumes" : "My resumes"),
          )
        ],
      ),
      body: _children[_currentIndex],
      floatingActionButton: (_currentIndex == 1 && (!apiConsumer.isAdmin))
          ? Builder(
              builder: (BuildContext context) => FloatingActionButton(
                    child: Icon(Icons.add),
                    onPressed: () {
                      _resumeDialog(context);
                    },
                  ))
          : null,
    );
  }

  void _resumeDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (_, StateSetter setState) => Dialog(
          child: Container(
            padding: EdgeInsets.all(8.0),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      RaisedButton(
                        color: _picture != null ? Colors.green : null,
                        child: Text(
                          "Select a photo",
                          style: TextStyle(
                            color: _picture != null ? Colors.white : null,
                          ),
                        ),
                        onPressed: () async {
                          final picked = await _picturePicker.getImage(
                              source: ImageSource.gallery);
                          setState(() => {_picture = File(picked.path)});
                        },
                        onLongPress: () {
                          setState(() => {_picture = null});
                        },
                      ),
                      RaisedButton(
                        color: _resume != null ? Colors.green : null,
                        child: Text(
                          "Select resume",
                          style: TextStyle(
                            color: _resume != null ? Colors.white : null,
                          ),
                        ),
                        onPressed: () async {
                          _resume = await FilePicker.getFile(
                            type: FileType.custom,
                            allowedExtensions: ["pdf"],
                          );
                          setState(() {});
                        },
                        onLongPress: () {
                          setState(() => {_resume = null});
                        },
                      ),
                    ],
                  ),
                  SizedBox(height: 16.0),
                  TextField(
                    keyboardType: TextInputType.name,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "First Name",
                      isDense: true,
                    ),
                    onChanged: (value) => {_firstName = value},
                  ),
                  SizedBox(height: 16.0),
                  TextField(
                    keyboardType: TextInputType.name,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "Last Name",
                      isDense: true,
                    ),
                    onChanged: (value) => {_lastName = value},
                  ),
                  SizedBox(height: 16.0),
                  TextField(
                    keyboardType: TextInputType.emailAddress,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "Email address",
                      isDense: true,
                    ),
                    onChanged: (value) => {_mail = value},
                  ),
                  SizedBox(height: 16.0),
                  TextField(
                    keyboardType: TextInputType.phone,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "Phone number",
                      isDense: true,
                    ),
                    onChanged: (value) => {_phoneNumber = value},
                  ),
                  SizedBox(height: 16.0),
                  Builder(
                    builder: (BuildContext context) => RaisedButton(
                      child: Text(
                        "My address",
                        style: TextStyle(
                            color: _address != null ? Colors.white : null),
                      ),
                      color: _address != null ? Colors.green : null,
                      onPressed: () async {
                        LocationResult result = await showLocationPicker(
                          context,
                          "AIzaSyAwiQLNE5idHfVFJFi3TV8Dvj2nondWzcE",
                          initialCenter: LatLng(48.866667, 2.333333),
                          myLocationButtonEnabled: true,
                          layersButtonEnabled: true,
                        );
                        setState(() => {
                              _address = result.latLng.latitude.toString() +
                                  "," +
                                  result.latLng.longitude.toString()
                            });
                      },
                    ),
                  ),
                  SizedBox(height: 16.0),
                  TextField(
                    keyboardType: TextInputType.multiline,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "Work experiences",
                      isDense: true,
                    ),
                    minLines: 2,
                    maxLines: null,
                    onChanged: (value) => {_wordExperiences = value},
                  ),
                  SizedBox(height: 16.0),
                  TextField(
                    keyboardType: TextInputType.multiline,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "Degrees",
                      isDense: true,
                    ),
                    minLines: 2,
                    maxLines: null,
                    onChanged: (value) => {_degrees = value},
                  ),
                  SizedBox(height: 16.0),
                  TextField(
                    keyboardType: TextInputType.multiline,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "Any comments ?",
                      isDense: true,
                    ),
                    minLines: 2,
                    maxLines: null,
                    onChanged: (value) => {_comment = value},
                  ),
                  SizedBox(height: 24.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Builder(
                        builder: (_) => RaisedButton(
                          textColor: Colors.white,
                          child: Text("Submit"),
                          color: Colors.green,
                          onPressed: () async {
                            if (await _createResume(context)) {
                              Navigator.of(context).pop();
                            }
                          },
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<bool> _createResume(BuildContext context) async {
    var resume = _resume?.readAsBytesSync();
    var picture = _picture?.readAsBytesSync();

    var submission = SubmissionModel(
        resume: resume != null ? base64Encode(resume) : null,
        picture: picture != null ? base64Encode(picture) : null,
        firstName: _firstName,
        lastName: _lastName,
        mail: _mail,
        phoneNumber: _phoneNumber,
        address: _address,
        workExperiences: _wordExperiences,
        degrees: _degrees,
        comment: _comment);

    return await apiConsumer.submissionApi.create(submission, context);
  }
}
