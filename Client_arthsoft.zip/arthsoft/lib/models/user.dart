import "dart:convert";

class UserModel {
  final int id;
  final String nickname;
  final String password;

  UserModel({this.id, this.nickname, this.password});

  factory UserModel.fromJson(Map<String, dynamic> json) =>
      UserModel(nickname: json["nickname"], password: json["password"]);

  String toJson() {
    return json.encode({
      if (nickname?.isNotEmpty ?? false) "nickname": nickname,
      if (password?.isNotEmpty ?? false) "password": password,
    });
  }
}
