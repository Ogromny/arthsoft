import "dart:convert";

class SubmissionModel {
  final int id;
  final String resume; // b64
  final String picture; // b64
  final String firstName;
  final String lastName;
  final String mail;
  final String phoneNumber;
  final String address; // coord (GMaps)
  final String workExperiences;
  final String degrees;
  final String comment;

  SubmissionModel(
      {this.id,
      this.resume,
      this.picture,
      this.firstName,
      this.lastName,
      this.mail,
      this.phoneNumber,
      this.address,
      this.workExperiences,
      this.degrees,
      this.comment});

  factory SubmissionModel.fromJson(Map<String, dynamic> json) =>
      SubmissionModel(
          id: json["id"],
          resume: json["resume"],
          picture: json["picture"],
          firstName: json["first_name"],
          lastName: json["last_name"],
          mail: json["mail"],
          phoneNumber: json["phone_number"],
          address: json["address"],
          workExperiences: json["work_experiences"],
          degrees: json["degrees"],
          comment: json["comment"]);

  String toJson() {
    return json.encode({
      if (resume?.isNotEmpty ?? false) "resume": resume,
      if (picture?.isNotEmpty ?? false) "picture": picture,
      if (firstName?.isNotEmpty ?? false) "first_name": firstName,
      if (lastName?.isNotEmpty ?? false) "last_name": lastName,
      if (mail?.isNotEmpty ?? false) "mail": mail,
      if (phoneNumber?.isNotEmpty ?? false) "phone_number": phoneNumber,
      if (address?.isNotEmpty ?? false) "address": address,
      if (workExperiences?.isNotEmpty ?? false)
        "work_experiences": workExperiences,
      if (degrees?.isNotEmpty ?? false) "degrees": degrees,
      if (comment?.isNotEmpty ?? false) "comment": comment,
    });
  }
}
